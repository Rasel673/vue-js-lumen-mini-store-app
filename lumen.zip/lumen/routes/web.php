<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/




$router->post('/registration','RegistrationController@onRegister');
$router->post('/select',['middleware'=>'auth','uses'=>'NumberController@selectUser']);
$router->post('/token',['middleware'=>'auth','uses'=>'NumberController@insert']);
$router->delete('/token',['middleware'=>'auth','uses'=>'NumberController@delete']);
////vue +lumen router------

///login routes------
$router->post('/login','LoginController@onlogin');
///category routes-------
$router->post('/Category','CategoryController@insert');
$router->get('/allCategory','CategoryController@allCategory');
$router->post('/updateCategory','CategoryController@update');
$router->post('/DeleteCategory','CategoryController@delete');
///supplier routes-----
$router->post('/Supplier','SupplierController@insert');
$router->get('/allSupplier','SupplierController@allSupplier');
$router->post('/updateSupplier','SupplierController@update');
$router->post('/DeleteSupplier','SupplierController@delete');
///product routes------------------------
$router->post('/Productadd','ProductController@insert');
$router->get('/allProduct','ProductController@allProducts');
$router->post('/updateProduct','ProductController@updateProduct');
$router->post('/DeleteProduct','ProductController@delete');
$router->Post('/showProduct','ProductController@show');






