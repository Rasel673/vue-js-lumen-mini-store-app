<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class SuppliersModel extends Model
{
     protected $table='suppliers';
    protected $primaryKey='id';
    public $incrementing=true;
    protected $keyType='int';
    public $timestamps=false;
}
