<?php

namespace App\Http\Controllers;
use App\CategoriesModel;
use App\RegistrationModel;
use \Firebase\JWT\JWT;
use Illuminate\Http\Request;



class CategoryController extends Controller
{

	//insert category..........
    function insert(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $name=$request->input('name');
       $description= $request->input('description');
      $verify=RegistrationModel::where('user_name',$user)->count();

      if($verify==1){
        $result=CategoriesModel::insert([
            'user_name'=>$user,
            'name'=>$name,
            'description'=>$description,
             ]);

        if($result){
            return response()->json(['status'=>"Category added successfuly"]);
        }
    }
     
    }
//all category..........
function allCategory(){
$result=CategoriesModel::all();
	if($result!=null){
      return response()->json($result);
	}else{
		return response()->json(['status'=>"No category available!! please insert category"]);
	}
}
//update category..........
 function update(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $id=$request->input('id');
        $name=$request->input('name');
       $description= $request->input('description');
      $verify=RegistrationModel::where('user_name',$user)->count();

      if($verify==1){
        $result=CategoriesModel::where('id',$id)->update([
            'user_name'=>$user,
            'name'=>$name,
            'description'=>$description,
             ]);

        if($result){
            return response()->json(['status'=>"Category updated successfuly"]);
        }
    }
     
    }

    //delete category..........

    function delete(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $id=$request->input('id');
      $verify=RegistrationModel::where('user_name',$user)->count();

      if($verify==1){
        $result=CategoriesModel::where('id',$id)->delete();
        if($result){
            return response()->json(['status'=>"Category Deleted successfuly"]);
        }
    }
     
    }
}
