<?php

namespace App\Http\Controllers;
use App\RegistrationModel;
use \Firebase\JWT\JWT;
use Illuminate\Http\Request;


class LoginController extends Controller
{

   
   function onlogin(Request $request){

    $this->validate($request, [
        
        'user_name' => 'required|exists:registration',
        'password' => 'required|exists:registration',

    ]);

   

    $key =env('TOKEN_KEY');
    $user_name=$request->input('user_name');
    $password=$request->input('password');
    $payload = array(
        "site" => "http://example.org",
        "user_name" =>$user_name,
        "iat" => time(),
        "exp" => time()+3600
    );
    $jwt = JWT::encode($payload, $key);
    return response()->json(['Token'=>$jwt,'status'=>"Login Success"]);
   }
}
