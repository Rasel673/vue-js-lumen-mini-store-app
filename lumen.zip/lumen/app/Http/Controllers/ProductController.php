<?php

namespace App\Http\Controllers;
use Intervention\Image\ImageManagerStatic as Image;
use App\RegistrationModel;
use App\ProductsModel;
use \Firebase\JWT\JWT;
use Illuminate\Http\Request;
use DB;

class ProductController extends Controller
{

 ///add products----------------------------------------   
  public  function insert(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
      $verify=RegistrationModel::where('user_name',$user)->count();
          if($verify==1){
    	$product_name=$request->input('name');
    	$cat_id=$request->input('category');
    	$sup_id=$request->input('supplier');
    	$product_price=$request->input('price');
    	$description=$request->input('description');
        $image=$request->input('image');
        
        
           $explode1=explode(',',$request->input('image'));
           $explode2=explode(';',$explode1[0]);
           $explode3=explode('/', $explode2[0]);
           $extention=$explode3[1];
           $filename=time().'.'.$extention;
           
    $img =Image::make($request->input('image'))->save(base_path('public/products/'.$filename),50);

            
            if ($img) {

            $result=ProductsModel::insert([
             	'name'=>$product_name,
             	'sup_id'=>$sup_id,
             	'cat_id'=>$cat_id,
             	'price'=>$product_price,
                'image'=>$filename,
             	'description'=>$description,
             	'user_name'=>$user
             ]);
            if($result){
            	 return response()->json(['status'=>"Product added successfuly"]);
            }
  
              }

    	
  } 
   


}

////all products----------------------------------------------------

public function allProducts(){
    $products=DB::table('products')
                ->join('categories','products.cat_id','=','categories.id')
                ->join('suppliers','products.sup_id','=','suppliers.id')
                ->select('products.*','categories.name as cat_name','suppliers.name as sup_name')
                ->orderBy('id','desc')
                ->get();
            if($products!=null){
      return response()->json($products);
    }else{
        return response()->json(['status'=>"No Products available!! please insert product"]);
    }   
}

///update product-----------------------------------------------
public function updateProduct(Request $request){

$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
      $verify=RegistrationModel::where('user_name',$user)->count();
          if($verify==1){
        $product_id=$request->input('id');    
        $product_name=$request->input('name');
        $cat_id=$request->input('cat_id');
        $sup_id=$request->input('sup_id');
        $product_price=$request->input('price');
        $description=$request->input('description');
        $image=$request->input('image');

        if($image){
        
           $explode1=explode(',',$request->input('image'));
           $explode2=explode(';',$explode1[0]);
           $explode3=explode('/', $explode2[0]);
           $extention=$explode3[1];
           $filename=time().'.'.$extention;
           
    $img =Image::make($request->input('image'))->save(base_path('public/products/'.$filename));

            if ($img) {

             $dltimg=ProductsModel::where('id',$product_id)->select('products.image')->first();
                unlink(base_path('public/products/'.$dltimg->image)); 
              $result1=ProductsModel::where('id',$product_id)->update([
                'name'=>$product_name,
                'sup_id'=>$sup_id,
                'cat_id'=>$cat_id,
                'price'=>$product_price,
                'image'=>$filename,
                'description'=>$description,
                'user_name'=>$user
             ]);
            if($result1){
                
                 return response()->json(['status'=>"Product updated successfuly"]);
            }

            }    
        }
        else{

             $result2=ProductsModel::where('id',$product_id)->update([
                'name'=>$product_name,
                'sup_id'=>$sup_id,
                'cat_id'=>$cat_id,
                'price'=>$product_price,
                'description'=>$description,
                'user_name'=>$user
             ]);
            if($result2){
                 return response()->json(['status'=>"Product updated successfuly"]);
            }

         }
  
          

        
  }     
}

////delete product-------------------------------------------

public function delete(Request $request){
           $token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
      $verify=RegistrationModel::where('user_name',$user)->count();
           if($verify==1){
            $product_id=$request->input('id');
            $dltimg=ProductsModel::where('id',$product_id)->select('products.image')->first();
               $delete=unlink(base_path('public/products/'.$dltimg->image));

            if($delete){

       $dlt=ProductsModel::where('id',$product_id)->delete();     
                
 return response()->json(['status'=>"Product deleted successfuly"]);
}

}


}
////show single product=========================================================
public function show(Request $request){
    $token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
      $verify=RegistrationModel::where('user_name',$user)->count();
           if($verify==1){
            $product_id=$request->input('id');

              $products=DB::table('products')->where('id',$product_id)->first();
                
                return response()->json($products);
}
}


}
