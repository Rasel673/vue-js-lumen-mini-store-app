<?php

namespace App\Http\Controllers;
use illuminate\support\Facades\DB;

class ExampleController extends Controller
{
  public function test(){
       $dbname=DB::Connection()->getdatabaseName();
       return  $dbname;
  }
}
