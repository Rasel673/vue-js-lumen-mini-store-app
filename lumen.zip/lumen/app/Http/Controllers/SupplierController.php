<?php

namespace App\Http\Controllers;
use App\SuppliersModel;
use App\RegistrationModel;
use \Firebase\JWT\JWT;
use Illuminate\Http\Request;

class SupplierController extends Controller
{

	//insert Supplier............................................................
    function insert(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $name=$request->input('name');
        $address=$request->input('address');
       $description= $request->input('description');
       $phone=$request->input('Phone');
        
      $verify=RegistrationModel::where('user_name',$user)->count();

      if($verify==1){
        $result=SuppliersModel::insert([
            'user_name'=>$user,
            'name'=>$name,
            'address'=>$address,
            'phone'=>$phone,
            'description'=>$description,
             ]);

        if($result){
            return response()->json(['status'=>"Supplier added successfuly"]);
        }
    }
}

//all Supplier..............................................................
function allSupplier(){
$result=SuppliersModel::all();
	if($result!=null){
      return response()->json($result);
	}else{
		return response()->json(['status'=>"No Supplier available!! please insert category"]);
	}
}

///update supplier-------------------------------------------------------

function update(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $id=$request->input('id');
        $name=$request->input('name');
        $address=$request->input('address');
       $description= $request->input('description');
       $phone=$request->input('Phone');
        
      $verify=RegistrationModel::where('user_name',$user)->count();

      if($verify==1){
        $result=SuppliersModel::where('id',$id)->update([
            'user_name'=>$user,
            'name'=>$name,
            'address'=>$address,
            'phone'=>$phone,
            'description'=>$description,
             ]);

        if($result){
            return response()->json(['status'=>"Supplier updated successfuly"]);
        }
    }
}
////delete supplier-----------------------------------------------------
 function delete(Request $request){

    	$token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $id=$request->input('id');
      $verify=RegistrationModel::where('user_name',$user)->count();

      if($verify==1){
        $result=SuppliersModel::where('id',$id)->delete();
        if($result){
            return response()->json(['status'=>"Supplier Deleted successfuly"]);
        }
    }
     
    }

    
}
