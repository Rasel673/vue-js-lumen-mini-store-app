<?php

namespace App\Http\Controllers;
use \Firebase\JWT\JWT;
use Illuminate\Http\Request;
use App\DetailsModel;

class NumberController extends Controller
{
    function selectUser(Request $request){
        $token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $result=DetailsModel::where('user_name',$user)->get();
        return $result;
    }

    function insert(Request $request){
        $token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $phone_number=$request->input('phone_number');
       $full_name= $request->input('full_name');
       $email= $request->input('email');
     
        $result=DetailsModel::insert([
            'user_name'=>$user,
            'phone_number'=>$phone_number,
            'full_name'=>$full_name,
            'email'=>$email
        ]);

        if($result){
            return "inserted successfuly";
        }else{
            return "fail!";
        }
     
    }

    function delete(Request $request){
        $token=$request->input('access_token');
        $key=env('TOKEN_KEY');
        $decoded = JWT::decode( $token, $key, array('HS256'));
        $decoded_array = (array) $decoded;
        $user= $decoded_array['user_name'];
        $email=$request->input('email');
        $result=DetailsModel::where(['user_name'=>$user,'email'=>$email])->delete();
        if ($result){
            return "deleted";
        }
    }
}
