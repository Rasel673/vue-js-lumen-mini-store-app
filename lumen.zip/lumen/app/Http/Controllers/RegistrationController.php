<?php

namespace App\Http\Controllers;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use App\RegistrationModel;

class RegistrationController extends Controller
{
   function onRegister(Request $request)
   {

    $this->validate($request, [
        
        'user_name' => 'unique:registration'
    ]);

    $first_name=$request->input('first_name');
    $last_name=$request->input('last_name');

   $city= $request->input('city');

    $user_name=$request->input('user_name');

    $password=$request->input('password');
    $gender=$request->input('gender');

    $result=RegistrationModel::insert([
        'first_name'=>$first_name,
        'last_name'=>$last_name,
        'city'=> $city,
        'user_name'=> $user_name,
        'password'=> $password,
        'gender'=> $gender

       ]);

       if($result){
                   return "registration successful";
               }else{
                return "registration failed";
               }
    
//     $user=RegistrationModel::where('user_name', $user_name)->count();
    
//     if($user!=0){
//      return "user name already exist!!";
//     }else{
//        $result=RegistrationModel::insert([
//         'first_name'=>$first_name,
//         'last_name'=>$last_name,
//         'city'=> $city,
//         'user_name'=> $user_name,
//         'password'=> $password,
//         'gender'=> $gender

//        ]);

//        if($result){
//            return "registration successful";
//        }else{
//         return "registration failed";
//        }
//    }

   }
}
